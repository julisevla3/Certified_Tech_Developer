public interface IDao <T>{
    public T salvar(T t);

}
